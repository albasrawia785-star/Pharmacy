package com.example.data

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File

class LocalDataService(private val context: Context) {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    private fun getFile(clientId: String, entityName: String): File {
        val dir = File(context.filesDir, "pharma_data/$clientId")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return File(dir, "$entityName.json")
    }

    fun <T> saveList(clientId: String, entityName: String, data: List<T>, elementClass: Class<T>) {
        try {
            val file = getFile(clientId, entityName)
            val type = Types.newParameterizedType(List::class.java, elementClass)
            val adapter = moshi.adapter<List<T>>(type)
            val json = adapter.toJson(data)
            file.writeText(json)
            Log.d("LocalDataService", "Saved $entityName successfully for client $clientId. Size: ${data.size}")
        } catch (e: Exception) {
            Log.e("LocalDataService", "Error saving $entityName for client $clientId", e)
        }
    }

    fun <T> loadList(clientId: String, entityName: String, elementClass: Class<T>): List<T> {
        try {
            val file = getFile(clientId, entityName)
            if (!file.exists()) {
                Log.d("LocalDataService", "File $entityName for client $clientId does not exist yet.")
                return emptyList()
            }
            val json = file.readText()
            if (json.isBlank() || json == "null") return emptyList()
            val type = Types.newParameterizedType(List::class.java, elementClass)
            val adapter = moshi.adapter<List<T>>(type)
            val result = adapter.fromJson(json) ?: emptyList()
            Log.d("LocalDataService", "Loaded $entityName successfully for client $clientId. Size: ${result.size}")
            return result
        } catch (e: Exception) {
            Log.e("LocalDataService", "Error loading $entityName for client $clientId", e)
            return emptyList()
        }
    }

    fun saveSettings(clientId: String, settings: Map<String, String>) {
        try {
            val file = getFile(clientId, "settings")
            val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
            val adapter = moshi.adapter<Map<String, String>>(type)
            val json = adapter.toJson(settings)
            file.writeText(json)
        } catch (e: Exception) {
            Log.e("LocalDataService", "Error saving settings for client $clientId", e)
        }
    }

    fun loadSettings(clientId: String): Map<String, String> {
        try {
            val file = getFile(clientId, "settings")
            if (!file.exists()) return emptyMap()
            val json = file.readText()
            if (json.isBlank() || json == "null") return emptyMap()
            val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
            val adapter = moshi.adapter<Map<String, String>>(type)
            return adapter.fromJson(json) ?: emptyMap()
        } catch (e: Exception) {
            Log.e("LocalDataService", "Error loading settings for client $clientId", e)
            return emptyMap()
        }
    }
}
