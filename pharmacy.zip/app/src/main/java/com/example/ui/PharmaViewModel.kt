package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FirebaseService
import com.example.data.Medicine
import com.example.data.Sale
import com.example.data.SaleItem
import com.example.data.User
import com.example.data.UserRole
import com.example.data.Category
import com.example.data.Company
import com.example.data.StockMovement
import com.example.data.ExpiredMedicine
import com.example.data.BarcodeHistoryItem
import com.squareup.moshi.Types
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

class PharmaViewModel(application: Application) : AndroidViewModel(application) {

    val firebaseService = FirebaseService(application)
    val localDataService = com.example.data.LocalDataService(application)

    fun logOperation(username: String, operationType: String, details: String) {
        viewModelScope.launch {
            try {
                val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                val logId = "log_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().take(4)
                val entry = com.example.data.LogEntry(
                    id = logId,
                    username = username,
                    dateTime = System.currentTimeMillis(),
                    dateStr = dateStr,
                    timeStr = timeStr,
                    operationType = operationType,
                    details = details
                )
                firebaseService.put("logs/$logId", entry, com.example.data.LogEntry::class.java)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Error logging operation to Firebase", e)
            }
        }
    }

    // حالة التحميل أثناء الاتصال بالشبكة
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // حالة المستخدم الحالي (الجلسة بالذاكرة المؤقتة فقط)
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // رسالة الخطأ لتسجيل الدخول أو العمليات الأخرى
    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    // قائمة المستخدمين (خاص بمدير النظام)
    private val _usersList = MutableStateFlow<List<User>>(emptyList())
    val usersList: StateFlow<List<User>> = _usersList.asStateFlow()

    // الأدوية للعميل الحالي
    private val _medicines = MutableStateFlow<List<Medicine>>(emptyList())
    val medicines: StateFlow<List<Medicine>> = _medicines.asStateFlow()

    // المبيعات للعميل الحالي
    private val _sales = MutableStateFlow<List<Sale>>(emptyList())
    val sales: StateFlow<List<Sale>> = _sales.asStateFlow()

    // سلة المبيعات الحالية (أثناء عملية البيع)
    private val _cart = MutableStateFlow<List<SaleItem>>(emptyList())
    val cart: StateFlow<List<SaleItem>> = _cart.asStateFlow()

    // التصنيفات للعميل الحالي
    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    // الشركات للعميل الحالي
    private val _companies = MutableStateFlow<List<Company>>(emptyList())
    val companies: StateFlow<List<Company>> = _companies.asStateFlow()

    // حركات المخزون للعميل الحالي
    private val _stockMovements = MutableStateFlow<List<StockMovement>>(emptyList())
    val stockMovements: StateFlow<List<StockMovement>> = _stockMovements.asStateFlow()

    // الأدوية منتهية الصلاحية المبلغ عنها للعميل الحالي
    private val _expiredMedicines = MutableStateFlow<List<ExpiredMedicine>>(emptyList())
    val expiredMedicines: StateFlow<List<ExpiredMedicine>> = _expiredMedicines.asStateFlow()

    // سجل المسح بالباركود للعميل الحالي
    private val _barcodeHistory = MutableStateFlow<List<BarcodeHistoryItem>>(emptyList())
    val barcodeHistory: StateFlow<List<BarcodeHistoryItem>> = _barcodeHistory.asStateFlow()

    init {
        // بذر البيانات الافتراضية لقاعدة بيانات Firebase Realtime عند بدء التشغيل
        viewModelScope.launch {
            try {
                _isLoading.value = true
                firebaseService.seedDatabaseIfNeeded()
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Error in initial seeding", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // تسجيل الدخول بالتحقق من Firebase Realtime Database
    fun login(username: String, password: String, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            _loginError.value = null
            try {
                val cleanedUsername = username.trim().lowercase()
                val userPath = "users/$cleanedUsername"
                
                // جلب بيانات المستخدم المحددة مباشرة من Firebase
                val user: User? = firebaseService.get(userPath, User::class.java)
                
                if (user == null) {
                    _loginError.value = "اسم المستخدم غير موجود أو البيانات غير صحيحة"
                    onResult(false)
                    return@launch
                }
                
                // التحقق من حالة الحساب
                if (user.status == "Suspended" || !user.active) {
                    _loginError.value = "هذا الحساب موقوف. يرجى مراجعة المسؤول"
                    onResult(false)
                    return@launch
                }
                
                if (user.status == "Deleted") {
                    _loginError.value = "هذا الحساب تم حذفه."
                    onResult(false)
                    return@launch
                }
                
                // التحقق من تاريخ الاشتراك
                val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                val hasExpired = (user.status == "Expired") || 
                        (user.subscriptionEnd.isNotBlank() && user.subscriptionEnd < todayStr)
                
                if (hasExpired) {
                    _loginError.value = "انتهت صلاحية الاشتراك. يرجى مراجعة مدير النظام."
                    onResult(false)
                    return@launch
                }

                // تشفير كلمة المرور المدخلة ومقارنتها
                val enteredHash = firebaseService.hashPassword(password)
                if (user.passwordHash != enteredHash) {
                    _loginError.value = "كلمة المرور غير صحيحة"
                    onResult(false)
                    return@launch
                }

                // التحقق من عدد الأجهزة
                val deviceId = android.provider.Settings.Secure.getString(
                    getApplication<Application>().contentResolver,
                    android.provider.Settings.Secure.ANDROID_ID
                ) ?: UUID.randomUUID().toString()

                val currentDevices = user.registeredDevices
                val isUnlimited = user.allowedDevices <= 0 || user.allowedDevices >= 9999
                
                val finalDevicesList = if (!currentDevices.contains(deviceId)) {
                    if (!isUnlimited && currentDevices.size >= user.allowedDevices) {
                        _loginError.value = "تجاوزت الحد الأقصى للأجهزة المسموح بها لهذا الحساب! الحد المسموح: ${user.allowedDevices}"
                        onResult(false)
                        return@launch
                    }
                    currentDevices + deviceId
                } else {
                    currentDevices
                }

                // تحديث آخر تسجيل دخول والأجهزة على سيرفر Firebase
                val updatedUser = user.copy(
                    lastLogin = System.currentTimeMillis(),
                    registeredDevices = finalDevicesList
                )
                firebaseService.put(userPath, updatedUser, User::class.java)

                // حفظ الجلسة في الذاكرة
                _currentUser.value = updatedUser
                
                // تسجيل العملية
                logOperation(updatedUser.username, "تسجيل الدخول", "تسجيل دخول ناجح على الجهاز ID: $deviceId")

                // جلب بيانات العميل الخاصة به حصراً (عزل البيانات)
                loadClientData(updatedUser.clientId)
                
                // إذا كان المدير، جلب قائمة المستخدمين أيضاً
                if (updatedUser.role == UserRole.ADMIN) {
                    fetchAllUsers()
                }

                onResult(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Login failure", e)
                _loginError.value = "فشل الاتصال بخادم Firebase"
                onResult(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // تسجيل الخروج
    fun logout() {
        val user = _currentUser.value
        if (user != null) {
            logOperation(user.username, "تسجيل الخروج", "تم تسجيل خروج المستخدم من التطبيق")
        }
        _currentUser.value = null
        _medicines.value = emptyList()
        _sales.value = emptyList()
        _cart.value = emptyList()
        _usersList.value = emptyList()
        _categories.value = emptyList()
        _companies.value = emptyList()
        _stockMovements.value = emptyList()
        _expiredMedicines.value = emptyList()
        _barcodeHistory.value = emptyList()
        _loginError.value = null
    }

    // تحميل بيانات عميل معين بشكل معزول ومستقل تماماً ومحلي بالكامل
    private fun loadClientData(clientId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // 1. تحميل الأدوية محلياً
                var localMeds = localDataService.loadList(clientId, "medicines", Medicine::class.java)
                if (localMeds.isEmpty()) {
                    // بذر أدوية افتراضية محلياً في البداية
                    localMeds = listOf(
                        Medicine("1", "Panadol Extra", "Paracetamol", 120, 2500.0, 1500.0, "مسكنات", "1010101", "2027-12", 20),
                        Medicine("2", "Amoclan 1g", "Amoxicillin", 45, 12500.0, 9000.0, "مضادات حيوية", "1010102", "2026-08", 15),
                        Medicine("3", "Brufen 400mg", "Ibuprofen", 85, 3000.0, 1800.0, "مضادات الالتهاب", "1010103", "2027-04", 10),
                        Medicine("4", "Ventolin Inhaler", "Salbutamol", 15, 8000.0, 5000.0, "بخاخات صدرية", "1010104", "2026-11", 5),
                        Medicine("5", "Lipitor 20mg", "Atorvastatin", 60, 15000.0, 11000.0, "أدوية الضغط والقلب", "1010105", "2028-01", 12)
                    )
                    localDataService.saveList(clientId, "medicines", localMeds, Medicine::class.java)
                }
                _medicines.value = localMeds

                // 2. تحميل المبيعات محلياً
                _sales.value = localDataService.loadList(clientId, "sales", Sale::class.java)

                // 3. تحميل التصنيفات محلياً
                var localCats = localDataService.loadList(clientId, "categories", Category::class.java)
                if (localCats.isEmpty()) {
                    localCats = listOf(
                        Category("cat1", "مسكنات", "#E57373", "MedicalServices", "أدوية تسكين الآلام"),
                        Category("cat2", "مضادات حيوية", "#81C784", "Medication", "مضادات البكتيريا والجراثيم"),
                        Category("cat3", "ضغط", "#64B5F6", "Favorite", "أدوية ارتفاع ضغط الدم والقلب"),
                        Category("cat4", "سكري", "#FFD54F", "Bloodtype", "أدوية وعلاجات السكري"),
                        Category("cat5", "فيتامينات", "#BA68C8", "Star", "مكملات غذائية وفيتامينات عامة"),
                        Category("cat6", "أطفال", "#FF8A65", "ChildCare", "أدوية وعلاجات الأطفال"),
                        Category("cat7", "جلدية", "#4DB6AC", "Healing", "كريمات ومراهم للجلدية"),
                        Category("cat8", "عيون", "#4DD0E1", "Visibility", "قطرات وعلاجات العيون"),
                        Category("cat9", "أنف وأذن", "#90A4AE", "Hearing", "بخاخات وعلاجات الأنف والأذن"),
                        Category("cat10", "مكملات غذائية", "#A1887F", "Restaurant", "بروتينات ومكملات غذائية رياضية")
                    )
                    localDataService.saveList(clientId, "categories", localCats, Category::class.java)
                }
                _categories.value = localCats

                // 4. تحميل الشركات محلياً
                var localComps = localDataService.loadList(clientId, "companies", Company::class.java)
                if (localComps.isEmpty()) {
                    localComps = listOf(
                        Company("comp1", "شركة الحكمة للأدوية", "الأردن", ""),
                        Company("comp2", "شركة سانوفي", "فرنسا", ""),
                        Company("comp3", "شركة فايزر", "أمريكا", ""),
                        Company("comp4", "شركة أسترازينيكا", "بريطانيا", ""),
                        Company("comp5", "شركة باير", "ألمانيا", "")
                    )
                    localDataService.saveList(clientId, "companies", localComps, Company::class.java)
                }
                _companies.value = localComps

                // 5. تحميل حركات المخزن محلياً
                _stockMovements.value = localDataService.loadList(clientId, "stockMovements", StockMovement::class.java)

                // 6. تحميل الأدوية التالفة محلياً
                _expiredMedicines.value = localDataService.loadList(clientId, "expiredMedicines", ExpiredMedicine::class.java)

                // 7. تحميل سجل الباركود محلياً
                _barcodeHistory.value = localDataService.loadList(clientId, "barcodeHistory", BarcodeHistoryItem::class.java)

            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Error loading client data from local storage", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // إضافة سجل حركة المخزون محلياً
    fun addStockMovementLocallyAndOnFirebase(clientId: String, movement: StockMovement) {
        viewModelScope.launch {
            try {
                val currentMovements = _stockMovements.value.toMutableList()
                currentMovements.add(0, movement) // إضافة للأحدث في البداية
                if (currentMovements.size > 150) { // الحفاظ على حجم البيانات معقولاً وسريعاً
                    currentMovements.removeLast()
                }

                localDataService.saveList(clientId, "stockMovements", currentMovements, StockMovement::class.java)
                _stockMovements.value = currentMovements
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save stock movement", e)
            }
        }
    }

    // إدارة المستودع: إضافة أو تعديل دواء مع حفظه محلياً للعميل الحالي
    fun saveMedicine(medicine: Medicine, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentList = _medicines.value.toMutableList()
                val index = currentList.indexOfFirst { it.id == medicine.id }
                
                // توليد باركود داخلي تلقائي إذا كان فارغاً
                val finalBarcode = if (medicine.barcode.isBlank() && medicine.internalBarcode.isBlank()) {
                    "INT-" + (100000 + (Math.random() * 900000).toInt())
                } else {
                    medicine.barcode
                }

                val finalInternalBarcode = if (medicine.internalBarcode.isBlank()) {
                    if (finalBarcode.startsWith("INT-")) finalBarcode else "INT-" + (100000 + (Math.random() * 900000).toInt())
                } else {
                    medicine.internalBarcode
                }

                val updatedMedicine = if (medicine.id.isBlank()) {
                    medicine.copy(
                        id = UUID.randomUUID().toString(),
                        barcode = finalBarcode,
                        internalBarcode = finalInternalBarcode,
                        qrCode = medicine.qrCode.ifBlank { "QR-${UUID.randomUUID().toString().take(8).uppercase()}" },
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis(),
                        createdBy = user.fullName.ifBlank { user.username }
                    )
                } else {
                    medicine.copy(
                        barcode = finalBarcode,
                        internalBarcode = finalInternalBarcode,
                        qrCode = medicine.qrCode.ifBlank { "QR-${UUID.randomUUID().toString().take(8).uppercase()}" },
                        updatedAt = System.currentTimeMillis()
                    )
                }

                // تحديد نوع حركة المخزون
                val movementType = if (index >= 0) {
                    val oldMed = currentList[index]
                    if (oldMed.price != updatedMedicine.price || oldMed.buyPrice != updatedMedicine.buyPrice) {
                        "تغيير سعر"
                    } else if (oldMed.quantity != updatedMedicine.quantity) {
                        "تعديل كمية"
                    } else {
                        "تعديل"
                    }
                } else {
                    "إضافة"
                }

                if (index >= 0) {
                    currentList[index] = updatedMedicine
                } else {
                    currentList.add(updatedMedicine)
                }

                // الحفظ محلياً في مسار العميل المعزول
                localDataService.saveList(user.clientId, "medicines", currentList, Medicine::class.java)
                _medicines.value = currentList
                
                // تسجيل حركة المخزون تلقائياً
                val movement = StockMovement(
                    id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                    medicineId = updatedMedicine.id,
                    medicineTradeName = updatedMedicine.tradeName,
                    type = movementType,
                    quantity = updatedMedicine.quantity,
                    user = user.fullName.ifBlank { user.username },
                    dateTime = System.currentTimeMillis(),
                    notes = "تم إجراء العملية في إدارة المستودع للعميل ${user.clientId}"
                )
                addStockMovementLocallyAndOnFirebase(user.clientId, movement)

                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save medicine locally", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // حذف دواء للعميل الحالي محلياً
    fun deleteMedicine(id: String, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        val medToDelete = _medicines.value.find { it.id == id } ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentList = _medicines.value.toMutableList()
                currentList.removeAll { it.id == id }

                localDataService.saveList(user.clientId, "medicines", currentList, Medicine::class.java)
                _medicines.value = currentList

                // تسجيل حركة المخزون لحذف الدواء
                val movement = StockMovement(
                    id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                    medicineId = medToDelete.id,
                    medicineTradeName = medToDelete.tradeName,
                    type = "حذف",
                    quantity = medToDelete.quantity,
                    user = user.fullName.ifBlank { user.username },
                    dateTime = System.currentTimeMillis(),
                    notes = "تم حذف الدواء تماماً من المستودع"
                )
                addStockMovementLocallyAndOnFirebase(user.clientId, movement)

                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to delete medicine locally", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // -------------------------------------------------------------------------
    // إدارة التصنيفات
    // -------------------------------------------------------------------------
    fun saveCategory(category: Category, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentCats = _categories.value.toMutableList()
                val targetCategory = if (category.id.isBlank()) {
                    category.copy(id = "cat_" + UUID.randomUUID().toString().take(6))
                } else {
                    category
                }

                val index = currentCats.indexOfFirst { it.id == targetCategory.id }
                if (index >= 0) {
                    currentCats[index] = targetCategory
                } else {
                    currentCats.add(targetCategory)
                }

                localDataService.saveList(user.clientId, "categories", currentCats, Category::class.java)
                _categories.value = currentCats
                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save category", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteCategory(id: String, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentCats = _categories.value.toMutableList()
                currentCats.removeAll { it.id == id }

                localDataService.saveList(user.clientId, "categories", currentCats, Category::class.java)
                _categories.value = currentCats
                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to delete category", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // -------------------------------------------------------------------------
    // إدارة الشركات المصنعة
    // -------------------------------------------------------------------------
    fun saveCompany(company: Company, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentComps = _companies.value.toMutableList()
                val targetCompany = if (company.id.isBlank()) {
                    company.copy(id = "comp_" + UUID.randomUUID().toString().take(6))
                } else {
                    company
                }

                val index = currentComps.indexOfFirst { it.id == targetCompany.id }
                if (index >= 0) {
                    currentComps[index] = targetCompany
                } else {
                    currentComps.add(targetCompany)
                }

                localDataService.saveList(user.clientId, "companies", currentComps, Company::class.java)
                _companies.value = currentComps
                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save company", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteCompany(id: String, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentComps = _companies.value.toMutableList()
                currentComps.removeAll { it.id == id }

                localDataService.saveList(user.clientId, "companies", currentComps, Company::class.java)
                _companies.value = currentComps
                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to delete company", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // -------------------------------------------------------------------------
    // إدارة الأدوية منتهية الصلاحية
    // -------------------------------------------------------------------------
    fun reportExpiredMedicine(expired: ExpiredMedicine, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val currentExps = _expiredMedicines.value.toMutableList()
                val targetExp = if (expired.id.isBlank()) {
                    expired.copy(
                        id = "exp_" + UUID.randomUUID().toString().take(6),
                        reportedAt = System.currentTimeMillis(),
                        reportedBy = user.fullName.ifBlank { user.username }
                    )
                } else {
                    expired
                }

                currentExps.add(0, targetExp)

                localDataService.saveList(user.clientId, "expiredMedicines", currentExps, ExpiredMedicine::class.java)
                _expiredMedicines.value = currentExps
                
                // تسجيل حركة المخزون
                val movement = StockMovement(
                    id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                    medicineId = targetExp.medicineId,
                    medicineTradeName = targetExp.tradeName,
                    type = "إرجاع",
                    quantity = targetExp.quantity,
                    user = user.fullName.ifBlank { user.username },
                    dateTime = System.currentTimeMillis(),
                    notes = "الإبلاغ عن دواء تالف/منتهي الصلاحية"
                )
                addStockMovementLocallyAndOnFirebase(user.clientId, movement)
                
                onComplete(true)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to report expired medicine", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // -------------------------------------------------------------------------
    // سجل مسح الباركود
    // -------------------------------------------------------------------------
    fun logBarcodeScan(barcode: String, medicineId: String, tradeName: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            try {
                val currentHistory = _barcodeHistory.value.toMutableList()
                val item = BarcodeHistoryItem(
                    id = "scan_" + UUID.randomUUID().toString().take(6),
                    barcode = barcode,
                    medicineId = medicineId,
                    tradeName = tradeName,
                    scannedAt = System.currentTimeMillis(),
                    scannedBy = user.fullName.ifBlank { user.username }
                )
                currentHistory.add(0, item)
                if (currentHistory.size > 100) {
                    currentHistory.removeLast()
                }

                localDataService.saveList(user.clientId, "barcodeHistory", currentHistory, BarcodeHistoryItem::class.java)
                _barcodeHistory.value = currentHistory
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to log barcode scan", e)
            }
        }
    }

    // جلب جميع المستخدمين لقاعدة البيانات (خاص بمدير النظام فقط)
    fun fetchAllUsers() {
        val user = _currentUser.value ?: return
        if (user.role != UserRole.ADMIN) return

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val usersType = Types.newParameterizedType(Map::class.java, String::class.java, User::class.java)
                val usersMap: Map<String, User>? = firebaseService.get("users", usersType)
                _usersList.value = usersMap?.values?.toList()?.sortedBy { it.username } ?: emptyList()
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Error fetching all users", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // إضافة أو تحديث مستخدم بالكامل على Firebase
    fun saveUser(targetUser: User, plainPassword: String?, onComplete: (Boolean) -> Unit) {
        val adminUser = _currentUser.value ?: return
        if (adminUser.role != UserRole.ADMIN) return

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val usernameClean = targetUser.username.trim().lowercase()
                val userPath = "users/$usernameClean"

                // قيود على الحساب 'ali' والمسؤولين الآخرين
                if (usernameClean == "ali") {
                    // للتأكد من عدم العبث بصلاحية أو نشاط حساب ali
                    if (targetUser.role != UserRole.ADMIN || !targetUser.active || targetUser.status != "Active") {
                        _loginError.value = "لا يمكن تعطيل أو تعديل صلاحيات حساب المدير العام الرئيسي!"
                        onComplete(false)
                        return@launch
                    }
                } else {
                    // لا يمكن إنشاء حساب Super Admin آخر
                    if (targetUser.role == UserRole.ADMIN) {
                        _loginError.value = "لا يمكن إنشاء حساب مدير عام آخر في النظام!"
                        onComplete(false)
                        return@launch
                    }
                }

                // جلب النسخة القديمة إذا كنا نقوم بالتعديل
                val existingUser: User? = firebaseService.get(userPath, User::class.java)

                // تجهيز الهاش لكلمة المرور
                val finalHash = if (!plainPassword.isNullOrBlank()) {
                    firebaseService.hashPassword(plainPassword)
                } else {
                    existingUser?.passwordHash ?: firebaseService.hashPassword("123456") // افتراضي إذا كان جديد ولم يحدد
                }

                val finalUser = targetUser.copy(
                    username = usernameClean,
                    passwordHash = finalHash,
                    userId = if (targetUser.userId.isBlank()) "usr_" + UUID.randomUUID().toString().take(6) else targetUser.userId,
                    createdAt = existingUser?.createdAt ?: System.currentTimeMillis()
                )

                val success = firebaseService.put(userPath, finalUser, User::class.java)
                if (success) {
                    val isNew = existingUser == null
                    val logType = when {
                        isNew -> "إنشاء مستخدم"
                        !plainPassword.isNullOrBlank() -> "إعادة تعيين كلمة المرور"
                        existingUser != null && existingUser.subscriptionEnd != targetUser.subscriptionEnd -> "تجديد اشتراك"
                        existingUser != null && existingUser.status != targetUser.status && targetUser.status == "Suspended" -> "إيقاف مستخدم"
                        else -> "تعديل مستخدم"
                    }
                    val logDetails = when {
                        isNew -> "إنشاء مستخدم جديد باسم $usernameClean وصلاحية ${targetUser.role}"
                        !plainPassword.isNullOrBlank() -> "إعادة تعيين كلمة مرور المستخدم $usernameClean"
                        existingUser != null && existingUser.subscriptionEnd != targetUser.subscriptionEnd -> "تجديد اشتراك المستخدم $usernameClean إلى ${targetUser.subscriptionEnd}"
                        existingUser != null && existingUser.status != targetUser.status -> "تغيير حالة المستخدم $usernameClean من ${existingUser.status} إلى ${targetUser.status}"
                        else -> "تعديل بيانات المستخدم $usernameClean"
                    }
                    logOperation(adminUser.username, logType, logDetails)

                    fetchAllUsers() // تحديث القائمة
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save user", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // حذف مستخدم من خادم Firebase
    fun deleteUser(username: String, onComplete: (Boolean) -> Unit) {
        val adminUser = _currentUser.value ?: return
        if (adminUser.role != UserRole.ADMIN) return

        val usernameClean = username.trim().lowercase()
        if (usernameClean == "ali") {
            onComplete(false)
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val success = firebaseService.delete("users/$usernameClean")
                if (success) {
                    logOperation(adminUser.username, "حذف مستخدم", "تم حذف حساب المستخدم $usernameClean")
                    fetchAllUsers()
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to delete user", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // تفعيل أو إيقاف حساب مستخدم
    fun toggleUserActive(username: String, active: Boolean, onComplete: (Boolean) -> Unit = {}) {
        val adminUser = _currentUser.value ?: return
        if (adminUser.role != UserRole.ADMIN) return

        val usernameClean = username.trim().lowercase()
        if (usernameClean == "ali") {
            onComplete(false)
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val userPath = "users/$usernameClean"
                val existingUser: User? = firebaseService.get(userPath, User::class.java)
                if (existingUser != null) {
                    val targetStatus = if (active) "Active" else "Suspended"
                    val updated = existingUser.copy(active = active, status = targetStatus)
                    val success = firebaseService.put(userPath, updated, User::class.java)
                    if (success) {
                        val logType = if (active) "تفعيل مستخدم" else "إيقاف مستخدم"
                        val logDetails = if (active) "تفعيل حساب المستخدم $usernameClean" else "إيقاف/تعطيل حساب المستخدم $usernameClean"
                        logOperation(adminUser.username, logType, logDetails)

                        fetchAllUsers()
                        onComplete(true)
                        return@launch
                    }
                }
                onComplete(false)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to toggle active user", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // إدارة السلة (محلي بالذاكرة المؤقتة أثناء عملية البيع)
    fun addToCart(medicineId: String, quantity: Int = 1) {
        val currentMedicines = _medicines.value
        val med = currentMedicines.find { it.id == medicineId } ?: return
        
        val alreadyInCart = _cart.value.find { it.medicineId == medicineId }?.quantity ?: 0
        if (med.quantity < alreadyInCart + quantity) {
            return 
        }

        val currentCart = _cart.value.toMutableList()
        val index = currentCart.indexOfFirst { it.medicineId == medicineId }
        if (index >= 0) {
            val existingItem = currentCart[index]
            currentCart[index] = existingItem.copy(quantity = existingItem.quantity + quantity)
        } else {
            currentCart.add(SaleItem(medicineId, med.tradeName, quantity, med.price))
        }
        _cart.value = currentCart
    }

    fun updateCartItemQuantity(medicineId: String, newQty: Int) {
        if (newQty <= 0) {
            removeFromCart(medicineId)
            return
        }
        val med = _medicines.value.find { it.id == medicineId } ?: return
        if (med.quantity < newQty) return 

        val currentCart = _cart.value.toMutableList()
        val index = currentCart.indexOfFirst { it.medicineId == medicineId }
        if (index >= 0) {
            currentCart[index] = currentCart[index].copy(quantity = newQty)
            _cart.value = currentCart
        }
    }

    fun removeFromCart(medicineId: String) {
        val currentCart = _cart.value.toMutableList()
        currentCart.removeAll { it.medicineId == medicineId }
        _cart.value = currentCart
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    // إتمام عملية البيع ورفع التحديثات فورياً ومزامنتها مع Firebase (الفاتورة البسيطة)
    fun checkout(customerName: String, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        val currentCart = _cart.value
        if (currentCart.isEmpty()) return

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val medList = _medicines.value.toMutableList()
                val salesList = _sales.value.toMutableList()

                var totalAmount = 0.0
                var totalCost = 0.0

                // تحديث كميات الأدوية محلياً أولاً
                for (item in currentCart) {
                    val medIndex = medList.indexOfFirst { it.id == item.medicineId }
                    if (medIndex >= 0) {
                        val med = medList[medIndex]
                        if (med.quantity < item.quantity) {
                            onComplete(false)
                            return@launch
                        }
                        medList[medIndex] = med.copy(quantity = med.quantity - item.quantity)
                        totalAmount += item.quantity * item.price
                        totalCost += item.quantity * med.buyPrice
                    }
                }

                // إنشاء الفاتورة الجديدة
                val newSale = Sale(
                    id = "S-${UUID.randomUUID().toString().take(6).uppercase()}",
                    date = Date(),
                    items = currentCart,
                    totalAmount = totalAmount,
                    totalCost = totalCost,
                    customerName = if (customerName.isNotBlank()) customerName else "زبون عام"
                )

                salesList.add(newSale)

                // رفع الأدوية المحدثة والمبيعات الجديدة إلى Firebase للعميل الحالي
                val medType = Types.newParameterizedType(List::class.java, Medicine::class.java)
                val salesType = Types.newParameterizedType(List::class.java, Sale::class.java)

                val medsUploaded = firebaseService.put("clients/${user.clientId}/medicines", medList, medType)
                val salesUploaded = firebaseService.put("clients/${user.clientId}/sales", salesList, salesType)

                if (medsUploaded && salesUploaded) {
                    _medicines.value = medList
                    _sales.value = salesList
                    _cart.value = emptyList() // تفريغ السلة

                    // تسجيل حركات المخزون للبيع في عملية واحدة سريعة وموفرة للشبكة
                    try {
                        val movementList = _stockMovements.value.toMutableList()
                        for (item in currentCart) {
                            val movement = StockMovement(
                                id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                                medicineId = item.medicineId,
                                medicineTradeName = item.tradeName,
                                type = "بيع",
                                quantity = item.quantity,
                                user = user.fullName.ifBlank { user.username },
                                dateTime = System.currentTimeMillis(),
                                notes = "عملية بيع بفاتورة رقم ${newSale.id}"
                            )
                            movementList.add(0, movement)
                        }
                        if (movementList.size > 150) {
                            while (movementList.size > 150) {
                                movementList.removeLast()
                            }
                        }
                        val movType = Types.newParameterizedType(List::class.java, StockMovement::class.java)
                        firebaseService.put("clients/${user.clientId}/stockMovements", movementList, movType)
                        _stockMovements.value = movementList
                    } catch (e: Exception) {
                        Log.e("PharmaViewModel", "Failed to upload stock movements for checkout", e)
                    }

                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Checkout failed", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // إتمام عملية البيع لنظام الـ POS الاحترافي
    fun checkoutPOS(
        customerName: String,
        discount: Double,
        paymentMethod: String,
        cartItems: List<SaleItem>,
        onComplete: (Sale?) -> Unit = {}
    ) {
        val user = _currentUser.value ?: return
        if (cartItems.isEmpty()) return

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val medList = _medicines.value.toMutableList()
                val salesList = _sales.value.toMutableList()

                var totalCost = 0.0
                var totalAmount = 0.0

                // تحديث كميات الأدوية محلياً أولاً
                for (item in cartItems) {
                    val medIndex = medList.indexOfFirst { it.id == item.medicineId }
                    if (medIndex >= 0) {
                        val med = medList[medIndex]
                        
                        val qtyToDeduct = when (item.unit) {
                            "شريط" -> {
                                val factorToUse = if (med.conversionFactor > 0) med.conversionFactor else 10
                                item.quantity.toDouble() / factorToUse
                            }
                            "حبة" -> {
                                val factor = if (med.conversionFactor > 0) med.conversionFactor else 30
                                item.quantity.toDouble() / factor
                            }
                            else -> item.quantity.toDouble()
                        }

                        val updatedQty = if (qtyToDeduct < 1.0 && qtyToDeduct > 0.0) {
                            (med.quantity - 1).coerceAtLeast(0)
                        } else {
                            (med.quantity - qtyToDeduct.toInt()).coerceAtLeast(0)
                        }

                        medList[medIndex] = med.copy(quantity = updatedQty)
                        
                        totalCost += item.quantity * med.buyPrice
                        totalAmount += item.quantity * item.price
                    }
                }

                val finalInvoiceAmount = (totalAmount - discount).coerceAtLeast(0.0)

                // إنشاء الفاتورة الجديدة
                val newSale = Sale(
                    id = "S-" + (100000 + (Math.random() * 900000).toInt()).toString(),
                    date = Date(),
                    items = cartItems,
                    totalAmount = finalInvoiceAmount,
                    totalCost = totalCost,
                    customerName = if (customerName.isNotBlank()) customerName else "زبون عام",
                    discount = discount,
                    paymentMethod = paymentMethod,
                    employeeName = user.fullName.ifBlank { user.username },
                    pharmacyName = user.pharmacyName.ifBlank { "صيدلية الدواء الذكي" },
                    status = "Completed",
                    qrCodeData = "INV-${UUID.randomUUID().toString().take(8).uppercase()}"
                )

                salesList.add(newSale)

                // الرفع والمزامنة
                val medType = Types.newParameterizedType(List::class.java, Medicine::class.java)
                val salesType = Types.newParameterizedType(List::class.java, Sale::class.java)

                val medsUploaded = firebaseService.put("clients/${user.clientId}/medicines", medList, medType)
                val salesUploaded = firebaseService.put("clients/${user.clientId}/sales", salesList, salesType)

                if (medsUploaded && salesUploaded) {
                    _medicines.value = medList
                    _sales.value = salesList
                    localDataService.saveList(user.clientId, "medicines", medList, Medicine::class.java)
                    localDataService.saveList(user.clientId, "sales", salesList, Sale::class.java)
                    clearPOSDraftCart() // مسح المسودة عند إتمام البيع بنجاح

                    // تسجيل حركة المخزن لكل صنف مباع
                    try {
                        val movementList = _stockMovements.value.toMutableList()
                        for (item in cartItems) {
                            val movement = StockMovement(
                                id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                                medicineId = item.medicineId,
                                medicineTradeName = item.tradeName,
                                type = "بيع",
                                quantity = item.quantity,
                                user = user.fullName.ifBlank { user.username },
                                dateTime = System.currentTimeMillis(),
                                notes = "بيع بالتجزئة (${item.unit}) - فاتورة POS رقم ${newSale.id}"
                            )
                            movementList.add(0, movement)
                        }
                        if (movementList.size > 150) {
                            while (movementList.size > 150) {
                                movementList.removeLast()
                            }
                        }
                        val movType = Types.newParameterizedType(List::class.java, StockMovement::class.java)
                        firebaseService.put("clients/${user.clientId}/stockMovements", movementList, movType)
                        _stockMovements.value = movementList
                        localDataService.saveList(user.clientId, "stockMovements", movementList, StockMovement::class.java)
                    } catch (e: Exception) {
                        Log.e("PharmaViewModel", "Failed to log movements for checkoutPOS", e)
                    }

                    logOperation(user.username, "بيع POS", "تم تسجيل مبيعات POS جديدة بقيمة $finalInvoiceAmount للفاتورة ${newSale.id}")
                    onComplete(newSale)
                } else {
                    onComplete(null)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "checkoutPOS failure", e)
                onComplete(null)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // تصفير وإعادة تعيين فاتورة POS مسودة
    fun savePOSDraftCart(cartItems: List<SaleItem>) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            try {
                localDataService.saveList(user.clientId, "pos_draft_cart", cartItems, SaleItem::class.java)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to save POS draft", e)
            }
        }
    }

    fun loadPOSDraftCart(): List<SaleItem> {
        val user = _currentUser.value ?: return emptyList()
        return try {
            localDataService.loadList(user.clientId, "pos_draft_cart", SaleItem::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearPOSDraftCart() {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            try {
                localDataService.saveList(user.clientId, "pos_draft_cart", emptyList<SaleItem>(), SaleItem::class.java)
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Failed to clear POS draft", e)
            }
        }
    }

    // إلغاء الفاتورة بالكامل (Void Sale)
    fun voidSale(saleId: String, reason: String, onComplete: (Boolean) -> Unit = {}) {
        val user = _currentUser.value ?: return
        if (user.role == UserRole.EMPLOYEE) {
            onComplete(false)
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val salesList = _sales.value.toMutableList()
                val medList = _medicines.value.toMutableList()
                
                val saleIndex = salesList.indexOfFirst { it.id == saleId }
                if (saleIndex < 0) {
                    onComplete(false)
                    return@launch
                }
                
                val sale = salesList[saleIndex]
                if (sale.status == "Voided") {
                    onComplete(false) // ملغية بالفعل
                    return@launch
                }
                
                // 1. إعادة الكميات للمستودع
                for (item in sale.items) {
                    val medIndex = medList.indexOfFirst { it.id == item.medicineId }
                    if (medIndex >= 0) {
                        val med = medList[medIndex]
                        medList[medIndex] = med.copy(quantity = med.quantity + item.quantity)
                    }
                }
                
                // 2. تحديث حالة الفاتورة
                val updatedSale = sale.copy(
                    status = "Voided",
                    voidReason = reason,
                    voidBy = user.fullName.ifBlank { user.username }
                )
                salesList[saleIndex] = updatedSale
                
                // 3. رفع التحديثات ومزامنتها سحابياً ومحلياً
                val medType = Types.newParameterizedType(List::class.java, Medicine::class.java)
                val salesType = Types.newParameterizedType(List::class.java, Sale::class.java)
                
                val medsUploaded = firebaseService.put("clients/${user.clientId}/medicines", medList, medType)
                val salesUploaded = firebaseService.put("clients/${user.clientId}/sales", salesList, salesType)
                
                if (medsUploaded && salesUploaded) {
                    _medicines.value = medList
                    _sales.value = salesList
                    localDataService.saveList(user.clientId, "medicines", medList, Medicine::class.java)
                    localDataService.saveList(user.clientId, "sales", salesList, Sale::class.java)
                    
                    // تسجيل حركة المخزون للإرجاع
                    try {
                        val movementList = _stockMovements.value.toMutableList()
                        for (item in sale.items) {
                            val movement = StockMovement(
                                id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                                medicineId = item.medicineId,
                                medicineTradeName = item.tradeName,
                                type = "إرجاع",
                                quantity = item.quantity,
                                user = user.fullName.ifBlank { user.username },
                                dateTime = System.currentTimeMillis(),
                                notes = "إرجاع دواء لإلغاء الفاتورة رقم ${sale.id}. السبب: $reason"
                            )
                            movementList.add(0, movement)
                        }
                        if (movementList.size > 150) {
                            while (movementList.size > 150) {
                                movementList.removeLast()
                            }
                        }
                        val movType = Types.newParameterizedType(List::class.java, StockMovement::class.java)
                        firebaseService.put("clients/${user.clientId}/stockMovements", movementList, movType)
                        _stockMovements.value = movementList
                        localDataService.saveList(user.clientId, "stockMovements", movementList, StockMovement::class.java)
                    } catch (e: Exception) {
                        Log.e("PharmaViewModel", "Failed to update stock movements for voidSale", e)
                    }
                    
                    logOperation(user.username, "إلغاء فاتورة", "تم إلغاء الفاتورة $saleId بالكامل. السبب: $reason")
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Void sale failed", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // نظام المرتجعات الجزئية (Refunds / Returns for specific items)
    fun returnSaleItem(
        saleId: String,
        medicineId: String,
        returnQty: Int,
        reason: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val salesList = _sales.value.toMutableList()
                val medList = _medicines.value.toMutableList()
                
                val saleIndex = salesList.indexOfFirst { it.id == saleId }
                if (saleIndex < 0) {
                    onComplete(false)
                    return@launch
                }
                
                val sale = salesList[saleIndex]
                val itemIndex = sale.items.indexOfFirst { it.medicineId == medicineId }
                if (itemIndex < 0) {
                    onComplete(false)
                    return@launch
                }
                
                val item = sale.items[itemIndex]
                if (returnQty <= 0 || returnQty > item.quantity) {
                    onComplete(false)
                    return@launch
                }
                
                // 1. إعادة الكمية المرجعة للمستودع
                val medIndex = medList.indexOfFirst { it.id == medicineId }
                var buyPrice = 0.0
                if (medIndex >= 0) {
                    val med = medList[medIndex]
                    buyPrice = med.buyPrice
                    medList[medIndex] = med.copy(quantity = med.quantity + returnQty)
                }
                
                // 2. تعديل الفاتورة
                val updatedItems = sale.items.toMutableList()
                val remainingQty = item.quantity - returnQty
                val itemPrice = item.price
                
                if (remainingQty == 0) {
                    updatedItems.removeAt(itemIndex)
                } else {
                    updatedItems[itemIndex] = item.copy(quantity = remainingQty)
                }
                
                val returnedValue = returnQty * itemPrice
                val returnedCost = returnQty * buyPrice
                
                val updatedSale = sale.copy(
                    items = updatedItems,
                    totalAmount = (sale.totalAmount - returnedValue).coerceAtLeast(0.0),
                    totalCost = (sale.totalCost - returnedCost).coerceAtLeast(0.0),
                    status = if (updatedItems.isEmpty()) "Voided" else sale.status,
                    voidReason = if (updatedItems.isEmpty()) "مرتجع بالكامل: $reason" else sale.voidReason
                )
                
                salesList[saleIndex] = updatedSale
                
                // 3. المزامنة والرفع سحابياً ومحلياً
                val medType = Types.newParameterizedType(List::class.java, Medicine::class.java)
                val salesType = Types.newParameterizedType(List::class.java, Sale::class.java)
                
                val medsUploaded = firebaseService.put("clients/${user.clientId}/medicines", medList, medType)
                val salesUploaded = firebaseService.put("clients/${user.clientId}/sales", salesList, salesType)
                
                if (medsUploaded && salesUploaded) {
                    _medicines.value = medList
                    _sales.value = salesList
                    localDataService.saveList(user.clientId, "medicines", medList, Medicine::class.java)
                    localDataService.saveList(user.clientId, "sales", salesList, Sale::class.java)
                    
                    // تسجيل الحركة المخزنية
                    try {
                        val movementList = _stockMovements.value.toMutableList()
                        val movement = StockMovement(
                            id = "MOV-" + UUID.randomUUID().toString().take(6).uppercase(),
                            medicineId = medicineId,
                            medicineTradeName = item.tradeName,
                            type = "إرجاع",
                            quantity = returnQty,
                            user = user.fullName.ifBlank { user.username },
                            dateTime = System.currentTimeMillis(),
                            notes = "إرجاع كمية $returnQty من الفاتورة رقم ${sale.id}. السبب: $reason"
                        )
                        movementList.add(0, movement)
                        if (movementList.size > 150) {
                            movementList.removeLast()
                        }
                        val movType = Types.newParameterizedType(List::class.java, StockMovement::class.java)
                        firebaseService.put("clients/${user.clientId}/stockMovements", movementList, movType)
                        _stockMovements.value = movementList
                        localDataService.saveList(user.clientId, "stockMovements", movementList, StockMovement::class.java)
                    } catch (e: Exception) {
                        Log.e("PharmaViewModel", "Failed to update movements for returnSaleItem", e)
                    }
                    
                    logOperation(user.username, "مرتجع مبيعات", "تم إرجاع $returnQty من الدواء ${item.tradeName} من الفاتورة ${saleId}. السبب: $reason")
                    onComplete(true)
                } else {
                    onComplete(false)
                }
            } catch (e: Exception) {
                Log.e("PharmaViewModel", "Return sale item failed", e)
                onComplete(false)
            } finally {
                _isLoading.value = false
            }
        }
    }
}
