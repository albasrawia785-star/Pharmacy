package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Teal / Emerald Medical Theme
val Mint80 = Color(0xFFA7F3D0)
val MintGrey80 = Color(0xFFD1FAE5)
val TealAccent80 = Color(0xFF99F6E4)

val Teal600 = Color(0xFF0D9488)
val Teal700 = Color(0xFF0F766E)
val Emerald500 = Color(0xFF10B981)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Rose500 = Color(0xFFEF4444)
val Amber500 = Color(0xFFF59E0B)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
