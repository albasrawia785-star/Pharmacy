package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.PharmaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun POSScreen(
    viewModel: PharmaViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val sales by viewModel.sales.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: POS, 1: Recent Invoices, 2: Refunds

    // حال السلة المؤقتة للـ POS (محلية بالذاكرة مع الحفظ التلقائي كمسودة)
    var posCart by remember { mutableStateOf<List<SaleItem>>(emptyList()) }
    var draftLoaded by remember { mutableStateOf(false) }

    // تحميل الفاتورة المسودة عند الفتح
    LaunchedEffect(currentUser) {
        if (currentUser != null && !draftLoaded) {
            posCart = viewModel.loadPOSDraftCart()
            draftLoaded = true
        }
    }

    // حفظ الفاتورة مسودة عند أي تغيير
    LaunchedEffect(posCart) {
        if (draftLoaded) {
            viewModel.savePOSDraftCart(posCart)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "نقطة البيع الاحترافية (POS)",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الموظف: ${currentUser?.fullName ?: currentUser?.username ?: "عام"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "صيدلية: ${currentUser?.pharmacyName ?: "الدواء الذكي"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // شريط التنقل بين تابات الـ POS
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    text = { Text("🔄 المرتجعات", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("🧾 آخر الفواتير", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text("🛒 بيع جديد", fontWeight = FontWeight.Bold) }
                )
            }

            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    slideInHorizontally { width -> if (targetState > initialState) width else -width } togetherWith
                            slideOutHorizontally { width -> if (targetState > initialState) -width else width }
                },
                label = "POS_Tabs"
            ) { tabIndex ->
                when (tabIndex) {
                    0 -> POSCheckoutTab(
                        viewModel = viewModel,
                        currentUser = currentUser,
                        medicines = medicines,
                        posCart = posCart,
                        onCartChange = { posCart = it }
                    )
                    1 -> RecentInvoicesTab(
                        viewModel = viewModel,
                        currentUser = currentUser,
                        sales = sales
                    )
                    2 -> RefundsTab(
                        viewModel = viewModel,
                        currentUser = currentUser,
                        sales = sales
                    )
                }
            }
        }
    }
}

// ==========================================
// تاب 1: الفاتورة وإتمام البيع (POS)
// ==========================================
@Composable
fun POSCheckoutTab(
    viewModel: PharmaViewModel,
    currentUser: User?,
    medicines: List<Medicine>,
    posCart: List<SaleItem>,
    onCartChange: (List<SaleItem>) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    
    // لإدخال الباركود يدوياً أو عبر قارئ خارجي (حيث يرسل النص وينتهي بـ Enter)
    var barcodeInputText by remember { mutableStateOf("") }

    // التحكم بالخصم العام (متاح للمدراء والمشرفين ومحمي للموظف)
    var invoiceDiscountVal by remember { mutableStateOf("") }
    val currentInvoiceDiscount = invoiceDiscountVal.toDoubleOrNull() ?: 0.0

    // طريقة الدفع
    var paymentMethod by remember { mutableStateOf("نقداً") } // نقداً، آجل، تحويل مصرفي، متعدد
    var customerName by remember { mutableStateOf("") }

    // دايلوج نجاح الطباعة وعرض الفاتورة
    var showReceiptDialog by remember { mutableStateOf(false) }
    var generatedInvoiceForReceipt by remember { mutableStateOf<Sale?>(null) }

    // دايلوج محاكاة الباركود بالكاميرا
    var showCameraSimDialog by remember { mutableStateOf(false) }

    // تصفية أدوية البحث
    val filteredMedicines = if (searchQuery.isBlank()) {
        emptyList()
    } else {
        medicines.filter { med ->
            med.tradeName.contains(searchQuery, ignoreCase = true) ||
            med.scientificName.contains(searchQuery, ignoreCase = true) ||
            med.barcode.contains(searchQuery) ||
            med.qrCode.contains(searchQuery) ||
            med.batchNumber.contains(searchQuery)
        }
    }

    // إضافة دواء للسلة بموجب الباركود
    fun addMedicineByBarcode(barcodeStr: String) {
        val med = medicines.find { it.barcode == barcodeStr || it.internalBarcode == barcodeStr || it.qrCode == barcodeStr }
        if (med != null) {
            if (med.quantity <= 0) {
                Toast.makeText(context, "⚠️ نفد المخزون: ${med.tradeName}", Toast.LENGTH_SHORT).show()
                return
            }
            // التحقق من التكرار لزيادة الكمية
            val existingIndex = posCart.indexOfFirst { it.medicineId == med.id && it.unit == "علبة" }
            if (existingIndex >= 0) {
                val updatedList = posCart.toMutableList()
                val oldItem = updatedList[existingIndex]
                if (oldItem.quantity + 1 > med.quantity) {
                    Toast.makeText(context, "⚠️ الحد الأقصى المتوفر: ${med.quantity}", Toast.LENGTH_SHORT).show()
                    return
                }
                updatedList[existingIndex] = oldItem.copy(quantity = oldItem.quantity + 1)
                onCartChange(updatedList)
            } else {
                val newList = posCart + SaleItem(
                    medicineId = med.id,
                    tradeName = med.tradeName,
                    quantity = 1,
                    price = med.price,
                    unit = "علبة",
                    discount = 0.0
                )
                onCartChange(newList)
            }
            Toast.makeText(context, "✅ تمت إضافة: ${med.tradeName}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "❌ لم يتم العثور على دواء بمطابقة: $barcodeStr", Toast.LENGTH_SHORT).show()
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // القسم الأيمن: شريط البحث والأدوية والعمليات السريعة (سعة 45%)
        Column(
            modifier = Modifier
                .weight(0.9f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            // قارئ الباركود واليدوي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر قارئ الكاميرا (المحاكي)
                Button(
                    onClick = { showCameraSimDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Camera Scanner")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الكاميرا", fontSize = 12.sp)
                }

                // حقل إدخال الباركود اليدوي / قارئ الباركود الخارجي
                OutlinedTextField(
                    value = barcodeInputText,
                    onValueChange = { barcodeInputText = it },
                    placeholder = { Text("امسح باركود أو اكتبه هنا...", fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Send
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f),
                    trailingIcon = {
                        IconButton(onClick = {
                            if (barcodeInputText.isNotBlank()) {
                                addMedicineByBarcode(barcodeInputText.trim())
                                barcodeInputText = ""
                            }
                        }) {
                            Icon(Icons.Default.Send, contentDescription = "Add Barcode")
                        }
                    }
                )
            }

            // مربع البحث الذكي
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث ذكي (الاسم، العلمي، الرف، الباركود...)", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                }
            )

            // عرض نتائج البحث الذكي مباشرة
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                        RoundedCornerShape(12.dp)
                    )
            ) {
                if (searchQuery.isBlank()) {
                    // إذا كان فارغاً نعرض اختصارات سريعة لـ POS
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "ابدأ بكتابة اسم الدواء أو مسح الباركود للبحث المباشر والبيع الفوري",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // شبكة الاختصارات السريعة لـ POS
                        Text(
                            "⚡ اختصارات العمليات السريعة",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onCartChange(emptyList()) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("إلغاء البيع", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = {
                                    if (posCart.isNotEmpty()) {
                                        // حفظ الفاتورة معلقة
                                        viewModel.savePOSDraftCart(posCart)
                                        Toast.makeText(context, "💾 تم حفظ الفاتورة كمسودة معلقة بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("تعليق الفاتورة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (filteredMedicines.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("❌ لا توجد أدوية مطابقة لبحثك", color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredMedicines) { med ->
                            POSMedicineSearchRow(
                                medicine = med,
                                onClick = {
                                    if (med.quantity <= 0) {
                                        Toast.makeText(context, "⚠️ نفد المخزون!", Toast.LENGTH_SHORT).show()
                                        return@POSMedicineSearchRow
                                    }
                                    
                                    // التحقق من تكرار نفس الدواء
                                    val existingIndex = posCart.indexOfFirst { it.medicineId == med.id && it.unit == "علبة" }
                                    if (existingIndex >= 0) {
                                        val updatedList = posCart.toMutableList()
                                        val oldItem = updatedList[existingIndex]
                                        if (oldItem.quantity + 1 > med.quantity) {
                                            Toast.makeText(context, "⚠️ نفدت الكمية الكلية المتوفرة!", Toast.LENGTH_SHORT).show()
                                            return@POSMedicineSearchRow
                                        }
                                        updatedList[existingIndex] = oldItem.copy(quantity = oldItem.quantity + 1)
                                        onCartChange(updatedList)
                                    } else {
                                        val newList = posCart + SaleItem(
                                            medicineId = med.id,
                                            tradeName = med.tradeName,
                                            quantity = 1,
                                            price = med.price,
                                            unit = "علبة",
                                            discount = 0.0
                                        )
                                        onCartChange(newList)
                                    }
                                    Toast.makeText(context, "✅ تمت إضافة ${med.tradeName}", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }

        // القسم الأيسر: سلة الفاتورة الحالية وتفاصيل الدفع (سعة 55%)
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.End
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onCartChange(emptyList()) }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear POS", tint = MaterialTheme.colorScheme.error)
                    }
                    Text(
                        text = "🛒 الفاتورة الحالية (${posCart.size} أصناف)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // قائمة عناصر السلة للـ POS
                if (posCart.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "الفاتورة فارغة حالياً.\nقم بالبحث عن دواء أو مسح باركود لإضافته هنا.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(posCart) { item ->
                            val linkedMedicine = medicines.find { it.id == item.medicineId }
                            POSCartItemRow(
                                item = item,
                                medicine = linkedMedicine,
                                userRole = currentUser?.role ?: UserRole.EMPLOYEE,
                                onUpdateItem = { updatedItem ->
                                    val updatedList = posCart.toMutableList()
                                    val idx = updatedList.indexOfFirst { it.medicineId == item.medicineId && it.unit == item.unit }
                                    if (idx >= 0) {
                                        if (updatedItem.quantity <= 0) {
                                            updatedList.removeAt(idx)
                                        } else {
                                            updatedList[idx] = updatedItem
                                        }
                                        onCartChange(updatedList)
                                    }
                                }
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // بيانات الدفع والزبون والخصومات
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        placeholder = { Text("اسم العميل (آجل أو نقدي)", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    )

                    // الخصم العام (للمدير فقط)
                    OutlinedTextField(
                        value = invoiceDiscountVal,
                        onValueChange = { 
                            if (currentUser?.role != UserRole.EMPLOYEE) {
                                invoiceDiscountVal = it
                            } else {
                                Toast.makeText(context, "⚠️ الموظف لا يملك صلاحية تعديل الخصومات العامة!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        placeholder = { Text("خصم الفاتورة ($)", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        enabled = currentUser?.role != UserRole.EMPLOYEE,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // خيارات طرق الدفع: نقداً، آجل، تحويل مصرفي، متعدد
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val methods = listOf("نقداً", "آجل", "تحويل", "متعدد")
                    methods.forEach { method ->
                        val isSelected = paymentMethod == method
                        Button(
                            onClick = { paymentMethod = method },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(method, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // الحسابات المالية قبل الحفظ
                val rawTotal = posCart.sumOf { item ->
                    item.price * item.quantity - item.discount
                }
                val netTotal = (rawTotal - currentInvoiceDiscount).coerceAtLeast(0.0)
                val totalPieces = posCart.sumOf { it.quantity }

                val totalCostOfCart = posCart.sumOf { item ->
                    val med = medicines.find { it.id == item.medicineId }
                    val buyPrice = med?.buyPrice ?: 0.0
                    buyPrice * item.quantity
                }
                val expectedProfit = (netTotal - totalCostOfCart).coerceAtLeast(0.0)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("$totalPieces قطعة / ${posCart.size} أصناف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("الكمية الكلية:", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("$${String.format("%.2f", rawTotal)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("الإجمالي الكلي قبل الخصم:", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    }
                    if (currentInvoiceDiscount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$${String.format("%.2f", currentInvoiceDiscount)}", fontSize = 11.sp, color = Color(0xFFD32F2F), fontWeight = FontWeight.Bold)
                            Text("الخصم العام المطبق:", fontSize = 11.sp, color = Color(0xFFD32F2F))
                        }
                    }
                    if (currentUser?.role != UserRole.EMPLOYEE) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$${String.format("%.2f", expectedProfit)}", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                            Text("الربح المتوقع لعملية البيع:", fontSize = 11.sp, color = Color(0xFF2E7D32))
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", netTotal)}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        )
                        Text(
                            text = "المبلغ النهائي (صافي):",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // زر تأكيد الفاتورة والبيع
                Button(
                    onClick = {
                        if (posCart.isEmpty()) {
                            Toast.makeText(context, "⚠️ السلة فارغة!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.checkoutPOS(
                            customerName = customerName,
                            discount = currentInvoiceDiscount,
                            paymentMethod = paymentMethod,
                            cartItems = posCart
                        ) { invoice ->
                            if (invoice != null) {
                                generatedInvoiceForReceipt = invoice
                                showReceiptDialog = true
                                onCartChange(emptyList()) // تفريغ السلة
                                customerName = ""
                                invoiceDiscountVal = ""
                            } else {
                                Toast.makeText(context, "❌ فشل إتمام البيع، يرجى فحص الشبكة والمخزون!", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.CreditCard, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إتمام وحفظ الفاتورة والطباعة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // دايلوج محاكاة الباركود
    if (showCameraSimDialog) {
        Dialog(onDismissRequest = { showCameraSimDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        "📷 محاكي قارئ باركود الكاميرا",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "اختر أحد الأدوية المتوفرة بمخزنك لمحاكاة التقاط كاميرا الهاتف لباركود العلبة تلقائياً:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Right
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .background(Color.Black, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // تأثير مرئي للماسح الضوئي الكاميرا
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("📱 [جاري محاكاة الكاميرا]", color = Color.Green, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = Color.Green, modifier = Modifier.fillMaxWidth(0.8f))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(medicines) { med ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (med.barcode.isNotBlank()) {
                                            addMedicineByBarcode(med.barcode)
                                            showCameraSimDialog = false
                                        } else {
                                            Toast.makeText(context, "⚠️ هذا الدواء لا يحتوي على باركود مسجل!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = med.barcode.ifBlank { "[بدون باركود]" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = med.tradeName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { showCameraSimDialog = false }, modifier = Modifier.align(Alignment.Start)) {
                        Text("إغلاق الكاميرا")
                    }
                }
            }
        }
    }

    // دايلوج عرض الفاتورة وطباعة الإيصال الرقمي للـ POS
    if (showReceiptDialog && generatedInvoiceForReceipt != null) {
        ReceiptDetailsDialog(
            invoice = generatedInvoiceForReceipt!!,
            onDismiss = { showReceiptDialog = false }
        )
    }
}

@Composable
fun POSMedicineSearchRow(
    medicine: Medicine,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = Icons.Default.AddCircle,
                contentDescription = "Add to Invoice",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )

            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            ) {
                Text(
                    text = medicine.tradeName,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Right
                )
                Text(
                    text = "العلمي: ${medicine.scientificName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    maxLines = 1,
                    textAlign = TextAlign.Right
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "متوفر: ${medicine.quantity} (${medicine.unit})",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (medicine.quantity == 0) Color.Red else if (medicine.quantity <= medicine.minRequiredQty) Color(0xFFD97706) else Color.Gray
                        )
                    )
                    Text(
                        text = "• السعر: $${medicine.price}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun POSCartItemRow(
    item: SaleItem,
    medicine: Medicine?,
    userRole: UserRole,
    onUpdateItem: (SaleItem) -> Unit
) {
    var editPriceOpen by remember { mutableStateOf(false) }
    var inputPrice by remember { mutableStateOf(item.price.toString()) }
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // زر الحذف
                IconButton(onClick = { onUpdateItem(item.copy(quantity = 0)) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }

                // تبديل وحدات البيع (علبة، شريط، حبة) مع التحويل التلقائي للأسعار والكميات
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    val units = listOf("علبة", "شريط", "حبة")
                    units.forEach { unit ->
                        val isSelected = item.unit == unit
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable {
                                    if (item.unit != unit && medicine != null) {
                                        val factor = if (medicine.conversionFactor > 0) medicine.conversionFactor else 10
                                        // حساب السعر التناسبي الجديد بناءً على اختيار الوحدة
                                        val calculatedPrice = when (unit) {
                                            "شريط" -> {
                                                // نفترض أن الشريط هو نصف أو ثلث السعر (مثلاً نقسم على 2 أو بناءً على معامل التحويل)
                                                medicine.price / 2.0
                                            }
                                            "حبة" -> {
                                                medicine.price / factor
                                            }
                                            else -> medicine.price
                                        }
                                        onUpdateItem(item.copy(unit = unit, price = calculatedPrice))
                                    }
                                }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(unit, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else Color.Black)
                        }
                    }
                }

                // التحكم بالكمية
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(onClick = { onUpdateItem(item.copy(quantity = item.quantity - 1)) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrement", modifier = Modifier.size(14.dp))
                    }
                    Text(
                        text = "${item.quantity}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = {
                        val maxAvailable = medicine?.quantity ?: 999
                        if (item.quantity + 1 > maxAvailable) {
                            Toast.makeText(context, "⚠️ تجاوزت الحد المتوفر بالمستودع!", Toast.LENGTH_SHORT).show()
                            return@IconButton
                        }
                        onUpdateItem(item.copy(quantity = item.quantity + 1))
                    }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Add, contentDescription = "Increment", modifier = Modifier.size(14.dp))
                    }
                }

                // تفاصيل الصنف والسعر
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                ) {
                    Text(
                        text = item.tradeName,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Right
                    )
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", item.price * item.quantity)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        )
                        Text(
                            text = "($${String.format("%.2f", item.price)}/${item.unit})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.clickable {
                                // تعديل سعر الصنف يدوياً للـ POS (مغلق للموظف، ومتاح للمدير لمرونة التفاوض)
                                if (userRole != UserRole.EMPLOYEE) {
                                    editPriceOpen = true
                                } else {
                                    Toast.makeText(context, "⚠️ الموظف العادي لا يملك صلاحية تغيير أسعار الأدوية!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
            }

            // حقل تعديل السعر اليدوي بموجب الصلاحيات
            if (editPriceOpen) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val newPrice = inputPrice.toDoubleOrNull()
                            if (newPrice != null && newPrice >= 0) {
                                onUpdateItem(item.copy(price = newPrice))
                                editPriceOpen = false
                            }
                        },
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("حفظ", fontSize = 10.sp)
                    }
                    OutlinedTextField(
                        value = inputPrice,
                        onValueChange = { inputPrice = it },
                        placeholder = { Text("السعر المخصص") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(40.dp),
                        shape = RoundedCornerShape(4.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            }
        }
    }
}

// ==========================================
// تاب 2: سجل الفواتير الأخيرة ومستنداتها
// ==========================================
@Composable
fun RecentInvoicesTab(
    viewModel: PharmaViewModel,
    currentUser: User?,
    sales: List<Sale>
) {
    val context = LocalContext.current
    var invoiceSearchQuery by remember { mutableStateOf("") }
    var selectedInvoiceForView by remember { mutableStateOf<Sale?>(null) }
    var voidingInvoiceId by remember { mutableStateOf<String?>(null) }
    var voidReasonInput by remember { mutableStateOf("") }

    val filteredSales = sales.filter { sale ->
        sale.id.contains(invoiceSearchQuery, ignoreCase = true) ||
        sale.customerName.contains(invoiceSearchQuery, ignoreCase = true) ||
        sale.paymentMethod.contains(invoiceSearchQuery)
    }.sortedByDescending { it.date }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.End
    ) {
        OutlinedTextField(
            value = invoiceSearchQuery,
            onValueChange = { invoiceSearchQuery = it },
            placeholder = { Text("ابحث برقم الفاتورة، طريقة الدفع أو الزبون...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredSales.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("لا توجد فواتير مبيعات مسجلة حتى الآن", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredSales) { sale ->
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                    val isVoided = sale.status == "Voided"

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isVoided) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isVoided) "❌ ملغية" else "✅ مكتملة",
                                    color = if (isVoided) Color.Red else Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "فاتورة #${sale.id}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = sdf.format(sale.date),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("$${String.format("%.2f", sale.totalAmount)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("الزبون: ${sale.customerName}", style = MaterialTheme.typography.bodySmall)
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("طريقة الدفع: ${sale.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text("بواسطة: ${sale.employeeName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            }

                            if (isVoided && sale.voidReason.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "سبب الإلغاء: ${sale.voidReason} (بواسطة: ${sale.voidBy})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Red,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // زر عرض وطباعة
                                Button(
                                    onClick = { selectedInvoiceForView = sale },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    modifier = Modifier.weight(1.5f),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("طباعة / إيصال", fontSize = 11.sp)
                                }

                                // زر إلغاء الفاتورة (للمدير فقط)
                                if (!isVoided) {
                                    OutlinedButton(
                                        onClick = {
                                            if (currentUser?.role != UserRole.EMPLOYEE) {
                                                voidingInvoiceId = sale.id
                                                voidReasonInput = ""
                                            } else {
                                                Toast.makeText(context, "⚠️ لا تملك صلاحيات إلغاء فواتير المبيعات، راجع المدير!", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إلغاء", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // تفاصيل الإيصال الفردي
    if (selectedInvoiceForView != null) {
        ReceiptDetailsDialog(invoice = selectedInvoiceForView!!, onDismiss = { selectedInvoiceForView = null })
    }

    // حوار تأكيد الإلغاء
    if (voidingInvoiceId != null) {
        AlertDialog(
            onDismissRequest = { voidingInvoiceId = null },
            title = {
                Text(
                    "إلغاء وتصفير فاتورة مبيعات؟",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "هل ترغب حقاً في إلغاء الفاتورة رقم #${voidingInvoiceId}؟ سيتم إعادة الكميات المباعة للمستودع وتعديل حسابات الأرباح فوراً.",
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = voidReasonInput,
                        onValueChange = { voidReasonInput = it },
                        placeholder = { Text("اكتب سبب إلغاء الفاتورة (مطلوب)...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (voidReasonInput.isBlank()) {
                            Toast.makeText(context, "يرجى كتابة سبب الإلغاء أولاً!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.voidSale(voidingInvoiceId!!, voidReasonInput) { success ->
                            if (success) {
                                Toast.makeText(context, "✅ تم إلغاء الفاتورة وإعادة الكميات للمخزن بنجاح", Toast.LENGTH_SHORT).show()
                                voidingInvoiceId = null
                            } else {
                                Toast.makeText(context, "❌ فشل إلغاء الفاتورة، يرجى المحاولة لاحقاً!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، إلغاء الفاتورة")
                }
            },
            dismissButton = {
                TextButton(onClick = { voidingInvoiceId = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// ==========================================
// تاب 3: المرتجعات المخصصة والجزئية للـ POS
// ==========================================
@Composable
fun RefundsTab(
    viewModel: PharmaViewModel,
    currentUser: User?,
    sales: List<Sale>
) {
    val context = LocalContext.current
    var inputInvoiceIdToRefund by remember { mutableStateOf("") }
    var loadedSaleToRefund by remember { mutableStateOf<Sale?>(null) }
    var returnReasonInput by remember { mutableStateOf("") }

    // التحكم بالكمية المرتجعة لكل صنف
    var itemToReturnMap by remember { mutableStateOf<Map<String, Int>>(emptyMap()) } // medicineId -> returnQty

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text(
            "🔄 نظام إرجاع وتعديل المبيعات والتجزئة",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Text(
            "اكتب رقم الفاتورة لتحميل عناصرها وإجراء عمليات المرتجع لمرتجعات الأدوية الفردية:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.padding(bottom = 12.dp),
            textAlign = TextAlign.Right
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val s = sales.find { it.id.trim().lowercase() == inputInvoiceIdToRefund.trim().lowercase() }
                    if (s != null) {
                        if (s.status == "Voided") {
                            Toast.makeText(context, "⚠️ هذه الفاتورة ملغية بالفعل بالكامل!", Toast.LENGTH_SHORT).show()
                            loadedSaleToRefund = null
                        } else {
                            loadedSaleToRefund = s
                            itemToReturnMap = s.items.associate { it.medicineId to 0 }
                            returnReasonInput = ""
                        }
                    } else {
                        Toast.makeText(context, "❌ لم يتم العثور على الفاتورة المعطاة!", Toast.LENGTH_SHORT).show()
                        loadedSaleToRefund = null
                    }
                },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("تحميل عناصر الفاتورة")
            }

            OutlinedTextField(
                value = inputInvoiceIdToRefund,
                onValueChange = { inputInvoiceIdToRefund = it },
                placeholder = { Text("رقم الفاتورة (مثال: S-12345)") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (loadedSaleToRefund != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "عناصر فاتورة #${loadedSaleToRefund!!.id} (الزبون: ${loadedSaleToRefund!!.customerName})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(loadedSaleToRefund!!.items) { item ->
                            val currentReturnQty = itemToReturnMap[item.medicineId] ?: 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // أزرار التحكم بالكمية المرتجعة
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (currentReturnQty > 0) {
                                                itemToReturnMap = itemToReturnMap + (item.medicineId to (currentReturnQty - 1))
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }

                                    Text(
                                        text = "$currentReturnQty",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )

                                    IconButton(
                                        onClick = {
                                            if (currentReturnQty < item.quantity) {
                                                itemToReturnMap = itemToReturnMap + (item.medicineId to (currentReturnQty + 1))
                                            } else {
                                                Toast.makeText(context, "لا يمكن إرجاع كمية أكبر من المباعة!", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(item.tradeName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("الكمية المباعة: ${item.quantity} - السعر: $${item.price}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = returnReasonInput,
                        onValueChange = { returnReasonInput = it },
                        placeholder = { Text("سبب إرجاع الصنف / المرتجع...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val activeReturns = itemToReturnMap.filter { it.value > 0 }
                            if (activeReturns.isEmpty()) {
                                Toast.makeText(context, "يرجى تحديد كمية دواء واحد على الأقل للمرتجع!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (returnReasonInput.isBlank()) {
                                Toast.makeText(context, "يرجى إدخال سبب المرتجع!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            // نقوم بإجراء عمليات المرتجع لكل صنف نشط بشكل تسلسلي
                            var successCount = 0
                            val totalToProcess = activeReturns.size
                            activeReturns.forEach { (medId, qty) ->
                                viewModel.returnSaleItem(loadedSaleToRefund!!.id, medId, qty, returnReasonInput) { success ->
                                    if (success) {
                                        successCount++
                                        if (successCount == totalToProcess) {
                                            Toast.makeText(context, "✅ تم إرجاع الأدوية المحددة وإعادة الكمية للمستودع وتعديل الحسابات بنجاح", Toast.LENGTH_LONG).show()
                                            loadedSaleToRefund = null
                                            inputInvoiceIdToRefund = ""
                                        }
                                    } else {
                                        Toast.makeText(context, "❌ فشل إتمام عملية المرتجع لبعض الأصناف", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("حفظ المرتجعات المحددة وإرسالها للمستودع", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// دايلوج تفاصيل الإيصال الرقمي POS والتصميم التجاري
// ==========================================
@Composable
fun ReceiptDetailsDialog(
    invoice: Sale,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // شعار الصيدلية
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalPharmacy,
                        contentDescription = "Pharmacy Logo",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = invoice.pharmacyName.ifBlank { "مستودع صيدلية الدواء الذكي" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "العنوان: بغداد، العراق | الهاتف: 07700000000",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "🧾 فاتورة مبيعات POS تجارية",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Gray, thickness = 1.dp)

                // معلومات الفاتورة الأساسية
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(invoice.id, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Text("رقم الفاتورة:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(sdf.format(invoice.date), style = MaterialTheme.typography.bodySmall)
                        Text("التاريخ والوقت:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(invoice.employeeName.ifBlank { "موظف مبيعات" }, style = MaterialTheme.typography.bodySmall)
                        Text("الموظف المسؤول:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(invoice.customerName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Text("الزبون:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(invoice.paymentMethod, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("طريقة الدفع:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Gray, thickness = 0.5.dp)

                // جدول المنتجات والأسعار
                Text(
                    "العناصر المباعة:",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )

                Spacer(modifier = Modifier.height(4.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    invoice.items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "$${String.format("%.2f", item.price * item.quantity)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${item.quantity} ${item.unit} x $${String.format("%.2f", item.price)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                            Text(
                                text = item.tradeName,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 120.dp),
                                textAlign = TextAlign.Right
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Gray, thickness = 1.dp)

                // الحساب الإجمالي والخصم
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    if (invoice.discount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$${String.format("%.2f", invoice.discount)}", style = MaterialTheme.typography.bodySmall, color = Color.Red)
                            Text("قيمة الخصم الكلي:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", invoice.totalAmount)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "المبلغ الصافي المدفوع:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // محاكاة QR Code وبار كود الفاتورة
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(8.dp)
                ) {
                    Text("|||||||||||||||||||||||", style = MaterialTheme.typography.bodyLarge, fontFamily = FontFamily.Monospace, color = Color.Black)
                    Text("BARCODE: ${invoice.id}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("[QR Code: https://smartpharma.gov/invoice/${invoice.id}]", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            Toast.makeText(context, "🖨️ تم إرسال الأمر للطباعة الفورية على طابعة الإيصالات الحرارية بنجاح!", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة حرارية POS")
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.weight(0.8f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إغلاق")
                    }
                }
            }
        }
    }
}
