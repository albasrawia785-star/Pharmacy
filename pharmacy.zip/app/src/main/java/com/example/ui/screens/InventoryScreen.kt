package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.Medicine
import com.example.data.UserRole
import com.example.ui.PharmaViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: PharmaViewModel,
    onNavigateBack: () -> Unit
) {
    val medicines by viewModel.medicines.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    // حالة الحوار (إضافة / تعديل دواء)
    var showDialog by remember { mutableStateOf(false) }
    var selectedMedicineForEdit by remember { mutableStateOf<Medicine?>(null) }

    // حالة حوار الاستيراد والتصدير
    var showImportExportDialog by remember { mutableStateOf(false) }

    // تصفية القائمة طبقاً للبحث والفلترة
    val filteredMedicines = medicines.filter { med ->
        val matchesSearch = med.tradeName.contains(searchQuery, ignoreCase = true) ||
                med.scientificName.contains(searchQuery, ignoreCase = true) ||
                med.barcode.contains(searchQuery)
        
        val matchesFilter = if (filterLowStockOnly) {
            med.quantity <= med.minRequiredQty
        } else {
            true
        }

        matchesSearch && matchesFilter
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        Text(
                            text = "مستودع الأدوية",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showImportExportDialog = true },
                        modifier = Modifier.testTag("import_export_inventory_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Import/Export CSV",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedMedicineForEdit = null
                    showDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("add_medicine_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Medicine", tint = Color.White)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            // شريط البحث والفلترة
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // زر فلترة النواقص
                FilterChip(
                    selected = filterLowStockOnly,
                    onClick = { filterLowStockOnly = !filterLowStockOnly },
                    label = { Text("النواقص فقط", fontSize = 12.sp) },
                    leadingIcon = if (filterLowStockOnly) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onErrorContainer
                    )
                )

                // حقل البحث
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن دواء...", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_medicine_input"),
                    trailingIcon = if (searchQuery.isNotEmpty()) {
                        {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    } else null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // عدد النتائج
            Text(
                text = "عدد الأدوية المتطابقة: ${filteredMedicines.size}",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                ),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // قائمة الأدوية
            if (filteredMedicines.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.HourglassEmpty,
                            contentDescription = "Empty",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد أدوية مطابقة للبحث",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredMedicines, key = { it.id }) { medicine ->
                        MedicineItemRow(
                            medicine = medicine,
                            isAdmin = currentUser?.role == UserRole.ADMIN,
                            onEdit = {
                                selectedMedicineForEdit = medicine
                                showDialog = true
                            },
                            onDelete = {
                                viewModel.deleteMedicine(medicine.id)
                            }
                        )
                    }
                }
            }
        }
    }

    // حوار الإضافة والتعديل المطور والمربوط بقاعدة البيانات
    if (showDialog) {
        MedicineFormDialog(
            medicine = selectedMedicineForEdit,
            viewModel = viewModel,
            onDismiss = { showDialog = false },
            onSave = { med ->
                viewModel.saveMedicine(med)
                showDialog = false
            }
        )
    }

    // حوار الاستيراد والتصدير
    if (showImportExportDialog) {
        ImportExportDialog(
            medicines = medicines,
            onDismiss = { showImportExportDialog = false },
            onImport = { importedMeds ->
                importedMeds.forEach { med ->
                    viewModel.saveMedicine(med)
                }
                Toast.makeText(context, "تم استيراد ${importedMeds.size} أدوية بنجاح!", Toast.LENGTH_SHORT).show()
                showImportExportDialog = false
            }
        )
    }
}

@Composable
fun MedicineItemRow(
    medicine: Medicine,
    isAdmin: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    // تحديد لون الكمية بناءً على المخزون
    val (qtyColor, qtyBg) = when {
        medicine.quantity == 0 -> Pair(MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f))
        medicine.quantity <= medicine.minRequiredQty -> Pair(Color(0xFFD97706), Color(0xFFFEF3C7)) // Amber
        else -> Pair(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f))
    }

    val qtyLabel = when {
        medicine.quantity == 0 -> "نفذ"
        medicine.quantity <= medicine.minRequiredQty -> "مخزون حرج"
        else -> "متوفر"
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() }
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // أزرار التحكم (تعديل وحذف)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (isAdmin) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                        )
                    }
                }
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // التفاصيل والسعر والكمية
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // السعر والكمية
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "$${medicine.price}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .background(color = qtyBg, shape = RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${medicine.quantity} ${medicine.unit} ($qtyLabel)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = qtyColor,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                // الاسم العلمي والتجاري والمنشأ
                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = medicine.tradeName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = medicine.scientificName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        ),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (medicine.expiryDate.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.padding(1.dp)
                            ) {
                                Text(
                                    text = "Exp: ${medicine.expiryDate}",
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = medicine.category,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineFormDialog(
    medicine: Medicine?,
    viewModel: PharmaViewModel,
    onDismiss: () -> Unit,
    onSave: (Medicine) -> Unit
) {
    val dbCategories by viewModel.categories.collectAsState()
    val dbCompanies by viewModel.companies.collectAsState()

    val categoryNames = remember(dbCategories) { dbCategories.map { it.name } }

    var tradeName by remember { mutableStateOf(medicine?.tradeName ?: "") }
    var scientificName by remember { mutableStateOf(medicine?.scientificName ?: "") }
    var quantityStr by remember { mutableStateOf(medicine?.quantity?.toString() ?: "") }
    var priceStr by remember { mutableStateOf(medicine?.price?.toString() ?: "") }
    var buyPriceStr by remember { mutableStateOf(medicine?.buyPrice?.toString() ?: "") }
    
    var category by remember { mutableStateOf(medicine?.category ?: (categoryNames.firstOrNull() ?: "عام")) }
    var categoryId by remember { mutableStateOf(medicine?.categoryId ?: (dbCategories.firstOrNull()?.id ?: "")) }
    
    var companyId by remember { mutableStateOf(medicine?.companyId ?: "") }
    var companyName by remember { 
        mutableStateOf(
            if (medicine != null && medicine.companyId.isNotBlank()) {
                dbCompanies.firstOrNull { it.id == medicine.companyId }?.name ?: ""
            } else {
                ""
            }
        ) 
    }
    var country by remember { mutableStateOf(medicine?.country ?: "") }
    
    var barcode by remember { mutableStateOf(medicine?.barcode ?: "") }
    var expiryDate by remember { mutableStateOf(medicine?.expiryDate ?: "2027-06-01") }
    var minRequiredQtyStr by remember { mutableStateOf(medicine?.minRequiredQty?.toString() ?: "10") }
    
    var strength by remember { mutableStateOf(medicine?.strength ?: "") }
    var dosageForm by remember { mutableStateOf(medicine?.dosageForm ?: "") }
    var batchNumber by remember { mutableStateOf(medicine?.batchNumber ?: "") }
    var location by remember { mutableStateOf(medicine?.location ?: "") }
    var notes by remember { mutableStateOf(medicine?.notes ?: "") }
    var unit by remember { mutableStateOf(medicine?.unit ?: "العلبة") }
    var conversionFactorStr by remember { mutableStateOf(medicine?.conversionFactor?.toString() ?: "1") }

    var expandedCategory by remember { mutableStateOf(false) }
    var expandedCompany by remember { mutableStateOf(false) }
    var expandedUnit by remember { mutableStateOf(false) }

    val units = listOf("الحبة", "الشريط", "العلبة", "الكارتون")

    var formError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .heightIn(max = 550.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = if (medicine == null) "إضافة دواء جديد" else "تعديل تفاصيل الدواء",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )

                Spacer(modifier = Modifier.height(16.dp))

                // قسم 1: المعلومات الأساسية
                SectionTitle(text = "المعلومات الأساسية")
                
                OutlinedTextField(
                    value = tradeName,
                    onValueChange = { tradeName = it },
                    label = { Text("الاسم التجاري (English)") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("trade_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = scientificName,
                    onValueChange = { scientificName = it },
                    label = { Text("الاسم العلمي (العربي)") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("scientific_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("رمز الباركود (اختياري)") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("barcode_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // قسم 2: التنظيم والتصنيف
                SectionTitle(text = "التنظيم والمنشأ")

                // اختيار الفئة الدوائية (قائمة ديناميكية من قاعدة البيانات)
                ExposedDropdownMenuBox(
                    expanded = expandedCategory,
                    onExpandedChange = { expandedCategory = !expandedCategory },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("الفئة الدوائية") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedCategory,
                        onDismissRequest = { expandedCategory = false }
                    ) {
                        dbCategories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = {
                                    category = cat.name
                                    categoryId = cat.id
                                    expandedCategory = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // اختيار الشركة المصنعة (قائمة ديناميكية من قاعدة البيانات)
                ExposedDropdownMenuBox(
                    expanded = expandedCompany,
                    onExpandedChange = { expandedCompany = !expandedCompany },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = if (companyName.isNotBlank()) "$companyName ($country)" else "اضغط لاختيار الشركة المصنعة",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("الشركة المصنعة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCompany) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedCompany,
                        onDismissRequest = { expandedCompany = false }
                    ) {
                        dbCompanies.forEach { comp ->
                            DropdownMenuItem(
                                text = { Text("${comp.name} - ${comp.country}") },
                                onClick = {
                                    companyName = comp.name
                                    companyId = comp.id
                                    country = comp.country
                                    expandedCompany = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = strength,
                        onValueChange = { strength = it },
                        label = { Text("التركيز") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = dosageForm,
                        onValueChange = { dosageForm = it },
                        label = { Text("الشكل الدوائي") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // قسم 3: الأسعار والمبيعات
                SectionTitle(text = "الأسعار والتكلفة ($)")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("سعر البيع ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("price_input")
                    )

                    OutlinedTextField(
                        value = buyPriceStr,
                        onValueChange = { buyPriceStr = it },
                        label = { Text("سعر الشراء ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("buy_price_input")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // قسم 4: الكميات والوحدات المختلفة للبيع
                SectionTitle(text = "إدارة الكميات ووحدات البيع")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityStr,
                        onValueChange = { quantityStr = it },
                        label = { Text("إجمالي الكمية") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("quantity_input")
                    )

                    OutlinedTextField(
                        value = minRequiredQtyStr,
                        onValueChange = { minRequiredQtyStr = it },
                        label = { Text("حد تنبيه النواقص") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // اختيار وحدة البيع الافتراضية
                    ExposedDropdownMenuBox(
                        expanded = expandedUnit,
                        onExpandedChange = { expandedUnit = !expandedUnit },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = unit,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("وحدة البيع") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedUnit) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedUnit,
                            onDismissRequest = { expandedUnit = false }
                        ) {
                            units.forEach { u ->
                                DropdownMenuItem(
                                    text = { Text(u) },
                                    onClick = {
                                        unit = u
                                        expandedUnit = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = conversionFactorStr,
                        onValueChange = { conversionFactorStr = it },
                        label = { Text("معامل التحويل") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // قسم 5: التشغيلة والموقع
                SectionTitle(text = "معلومات التشغيلة والمستودع")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = batchNumber,
                        onValueChange = { batchNumber = it },
                        label = { Text("رقم التشغيلة") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("تاريخ الصلاحية YYYY-MM") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("موقع الدواء في الرف") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                if (formError != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = formError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (tradeName.isBlank() || scientificName.isBlank()) {
                                formError = "يرجى إدخال الاسم العلمي والتجاري"
                                return@Button
                            }
                            val qty = quantityStr.toIntOrNull()
                            val price = priceStr.toDoubleOrNull()
                            val buyPrice = buyPriceStr.toDoubleOrNull()
                            val minQty = minRequiredQtyStr.toIntOrNull() ?: 10
                            val convFactor = conversionFactorStr.toIntOrNull() ?: 1

                            if (qty == null || price == null || buyPrice == null) {
                                formError = "يرجى إدخال قيم صالحة للأرقام"
                                return@Button
                            }

                            val newOrUpdated = Medicine(
                                id = medicine?.id ?: "",
                                tradeName = tradeName,
                                scientificName = scientificName,
                                quantity = qty,
                                price = price,
                                buyPrice = buyPrice,
                                category = category,
                                categoryId = categoryId,
                                companyId = companyId,
                                country = country,
                                barcode = barcode,
                                expiryDate = expiryDate,
                                minRequiredQty = minQty,
                                strength = strength,
                                dosageForm = dosageForm,
                                batchNumber = batchNumber,
                                location = location,
                                notes = notes,
                                unit = unit,
                                conversionFactor = convFactor,
                                salePrice = price,
                                purchasePrice = buyPrice,
                                lastSalePrice = medicine?.lastSalePrice ?: price,
                                lastPurchasePrice = medicine?.lastPurchasePrice ?: buyPrice,
                                minimumSalePrice = medicine?.minimumSalePrice ?: price,
                                profit = price - buyPrice,
                                createdAt = medicine?.createdAt ?: System.currentTimeMillis(),
                                updatedAt = System.currentTimeMillis()
                            )
                            onSave(newOrUpdated)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f).testTag("save_medicine_button")
                    ) {
                        Text("حفظ")
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = Alignment.End) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        )
        Divider(
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        )
        Spacer(modifier = Modifier.height(6.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportExportDialog(
    medicines: List<Medicine>,
    onDismiss: () -> Unit,
    onImport: (List<Medicine>) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("تصدير (CSV)", "استيراد (CSV)")
    val context = LocalContext.current

    // توليد نص الـ CSV للتصدير
    val csvExportContent = remember(medicines) {
        val builder = StringBuilder()
        builder.append("الاسم التجاري,الاسم العلمي,الكمية,سعر البيع,سعر الشراء,الفئة,الباركود,الصلاحية,الحد الأدنى,رقم التشغيلة,الوحدة,الموقع\n")
        for (m in medicines) {
            builder.append("\"${m.tradeName}\",\"${m.scientificName}\",${m.quantity},${m.price},${m.buyPrice},\"${m.category}\",\"${m.barcode}\",\"${m.expiryDate}\",${m.minRequiredQty},\"${m.batchNumber}\",\"${m.unit}\",\"${m.location}\"\n")
        }
        builder.toString()
    }

    var csvImportInput by remember { mutableStateOf("") }
    var importError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "استيراد وتصدير بيانات المخزن",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index; importError = null },
                            text = { Text(title, fontSize = 13.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedTab == 0) {
                    // تصدير
                    Text(
                        text = "انسخ محتوى الـ CSV أدناه لمشاركته أو لحفظه بملف Excel:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = csvExportContent,
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 8,
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            val clipData = android.content.ClipData.newPlainText("Medicines CSV", csvExportContent)
                            clipboardManager.setPrimaryClip(clipData)
                            Toast.makeText(context, "تم نسخ المخزن بصيغة CSV للحافظة!", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ محتوى الـ CSV للذاكرة")
                    }
                } else {
                    // استيراد
                    Text(
                        text = "ألصق محتوى الـ CSV أدناه (تأكد أن السطر الأول يحتوي على أسماء الأعمدة):",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = csvImportInput,
                        onValueChange = { csvImportInput = it; importError = null },
                        placeholder = { Text("الاسم التجاري,الاسم العلمي,الكمية,سعر البيع,سعر الشراء...") },
                        maxLines = 8,
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        modifier = Modifier.fillMaxWidth().testTag("import_csv_input")
                    )

                    if (importError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = importError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Right
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            if (csvImportInput.isBlank()) {
                                importError = "يرجى إلصاق محتوى CSV أولاً!"
                                return@Button
                            }
                            try {
                                val lines = csvImportInput.lines().filter { it.isNotBlank() }
                                if (lines.size <= 1) {
                                    importError = "المحتوى فارغ أو لا يحتوي على أسطر بيانات!"
                                    return@Button
                                }
                                val importedList = mutableListOf<Medicine>()
                                // تخطي رأس الملف (السطر الأول)
                                for (i in 1 until lines.size) {
                                    val line = lines[i]
                                    // تقسيم يدوي للـ CSV مع إهمال علامات الاقتباس
                                    val parts = line.split(",").map { it.replace("\"", "").trim() }
                                    if (parts.size >= 5) {
                                        val trade = parts[0]
                                        val scientific = parts[1]
                                        val qty = parts[2].toIntOrNull() ?: 0
                                        val price = parts[3].toDoubleOrNull() ?: 0.0
                                        val buyPrice = parts[4].toDoubleOrNull() ?: 0.0
                                        val cat = if (parts.size > 5) parts[5] else "عام"
                                        val bar = if (parts.size > 6) parts[6] else ""
                                        val exp = if (parts.size > 7) parts[7] else "2027-06-01"
                                        val min = if (parts.size > 8) parts[8].toIntOrNull() ?: 10 else 10
                                        val batch = if (parts.size > 9) parts[9] else ""
                                        val unit = if (parts.size > 10) parts[10] else "العلبة"
                                        val loc = if (parts.size > 11) parts[11] else ""

                                        if (trade.isNotBlank() && scientific.isNotBlank()) {
                                            importedList.add(
                                                Medicine(
                                                    id = "",
                                                    tradeName = trade,
                                                    scientificName = scientific,
                                                    quantity = qty,
                                                    price = price,
                                                    buyPrice = buyPrice,
                                                    category = cat,
                                                    barcode = bar,
                                                    expiryDate = exp,
                                                    minRequiredQty = min,
                                                    batchNumber = batch,
                                                    unit = unit,
                                                    location = loc,
                                                    createdAt = System.currentTimeMillis(),
                                                    updatedAt = System.currentTimeMillis()
                                                )
                                            )
                                        }
                                    }
                                }
                                if (importedList.isEmpty()) {
                                    importError = "فشل تحليل الأسطر. تحقق من الفواصل التنسيقية!"
                                } else {
                                    onImport(importedList)
                                }
                            } catch (e: Exception) {
                                importError = "خطأ أثناء المعالجة: ${e.localizedMessage}"
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth().testTag("confirm_import_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("بدء الاستيراد والحفظ سحابياً")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إلغاء وإغلاق")
                }
            }
        }
    }
}
